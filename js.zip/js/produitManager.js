class productManager{
    constructor(listProduct){
        this.listProduct = jsonProduct.listProduct;
    }
}